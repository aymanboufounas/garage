# GarageShare website 0.7.0

The source includes the website, Node.js API, SQLite schema, support dashboard, assets and tests.

## Run locally

Install Node.js 24 or newer and open a terminal in this folder.

```bash
npm run demo
```

Open [http://localhost:3000](http://localhost:3000) for sample listings. Use `npm start` in a fresh terminal for a local installation with its own database. Run `npm test` to verify the code.

## Deploy

Use the [VPS deployment guide](docs/DEPLOYMENT.md) to run the app with persistent SQLite storage and HTTPS. Once DNS and HTTPS are set up, set `APP_ORIGIN=https://app.garageshare.xyz` on the server.

Follow the [Google sign-in setup](docs/DEPLOYMENT.md#enable-google-sign-in) to configure the OAuth client. The [support dashboard setup](docs/DEPLOYMENT.md#set-up-the-support-dashboard) explains how to grant staff access.

[Source snapshot on GitHub](https://github.com/aymanboufounas/garage/tree/a692be83f2914a6d3f0907afef2282ac06da9aa1)
